package com.rishad.springdata.idgenerators;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdgeneratorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdgeneratorsApplication.class, args);
	}

}
