package com.rishad.springdata.idgenerators;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdgeneratorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
